package com.thbproject.biofits.service;

import org.springframework.data.domain.AuditorAware;

public class AuditorService implements AuditorAware<String> {

	@Override
	public String getCurrentAuditor() {
		// TODO Auto-generated method stub
		return null;
	}

}
